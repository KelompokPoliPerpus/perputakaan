export class User {
    userid: number;
    username: string;
    useremail: string;
    userpassword: string;
}