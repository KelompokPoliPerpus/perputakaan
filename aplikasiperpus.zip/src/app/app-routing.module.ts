import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './guard/auth.guard';

const routes: Routes = [
  { path: '', redirectTo: 'landing', pathMatch: 'full' },
  { path: 'landing', loadChildren: './pages/landing/landing.module#LandingPageModule' },
  { path: 'login', loadChildren: './pages/auth/login/login.module#LoginPageModule' },
  { path: 'register', loadChildren: './pages/auth/register/register.module#RegisterPageModule' },

  { path: 'home', loadChildren: './home/home.module#HomePageModule', canActivate: [AuthGuard] },

  // { path: 'tab1', loadChildren: './tab1/tab1.module#Tab1PageModule' },
  // { path: 'tab2', loadChildren: './tab2/tab2.module#Tab1PageModule' },
  // { path: 'tab3', loadChildren: './tab3/tab3.module#Tab1PageModule' },

  // { path: 'tab1', loadChildren: './tab1/tab1.module#Tab1PageModule', canActivate: [AuthGuard] },
  // { path: 'tab2', loadChildren: './tab2/tab2.module#Tab1PageModule', canActivate: [AuthGuard] },
  // { path: 'tab3', loadChildren: './tab3/tab3.module#Tab1PageModule', canActivate: [AuthGuard] },
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
