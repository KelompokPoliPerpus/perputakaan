-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2019 at 06:42 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbperpus`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_book`
--

CREATE TABLE `tb_book` (
  `id_book` int(10) NOT NULL,
  `book_title` varchar(255) NOT NULL,
  `book_author` varchar(255) NOT NULL,
  `book_img` varchar(255) NOT NULL,
  `book_desc` longtext NOT NULL,
  `ISBN10` varchar(10) NOT NULL,
  `ISBN13` varchar(14) NOT NULL,
  `book_publisher` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_book`
--

INSERT INTO `tb_book` (`id_book`, `book_title`, `book_author`, `book_img`, `book_desc`, `ISBN10`, `ISBN13`, `book_publisher`) VALUES
(1, 'Becoming : Michelle Obama', 'Michelle Obama', 'http://localhost:8081/img/becoming.jpg', 'In a life filled with meaning and accomplishment, Michelle Obama has emerged as one of the most iconic and compelling women of our era. As First Lady of the United States of America—the first African American to serve in that role—she helped create the most welcoming and inclusive White House in history, while also establishing herself as a powerful advocate for women and girls in the U.S. and around the world, dramatically changing the ways that families pursue healthier and more active lives, and standing with her husband as he led America through some of its most harrowing moments. Along the way, she showed us a few dance moves, crushed Carpool Karaoke, and raised two down-to-earth daughters under an unforgiving media glare. \r\n \r\nIn her memoir, a work of deep reflection and mesmerizing storytelling, Michelle Obama invites readers into her world, chronicling the experiences that have shaped her—from her childhood on the South Side of Chicago to her years as an executive balancing the demands of motherhood and work, to her time spent at the world’s most famous address. With unerring honesty and lively wit, she describes her triumphs and her disappointments, both public and private, telling her full story as she has lived it—in her own words and on her own terms. Warm, wise, and revelatory, Becoming is the deeply personal reckoning of a woman of soul and substance who has steadily defied expectations—and whose story inspires us to do the same.', '1524763136', '978-1524763138', 'Crown Publishing Group; 1st Edition edition (November 13, 2018)'),
(2, 'Girl, Stop Apologizing: A Shame-Free Plan for Embracing and Achieving Your Goals', 'Rachel Hollis', 'http://localhost:8081/img/girl stop apologizing.jpg', 'Rachel Hollis has seen it too often: women not living into their full potential. They feel a tugging on their hearts for something more, but they’re afraid of embarrassment, of falling short of perfection, of not being enough.\r\n\r\nIn Girl, Stop Apologizing, #1 New York Times bestselling author and founder of a multimillion-dollar media company, Rachel Hollis sounds a wake-up call. She knows that many women have been taught to define themselves in light of other people—whether as wife, mother, daughter, or employee—instead of learning how to own who they are and what they want. With a challenge to women everywhere to stop talking themselves out of their dreams, Hollis identifies the excuses to let go of, the behaviors to adopt, and the skills to acquire on the path to growth, confidence, and believing in yourself.Age Range:Adult', '1400209609', '978-1400209606', 'HarperCollins Leadership (March 5, 2019)'),
(3, 'The Right Side of History: How Reason and Moral Purpose Made the West Great', 'Ben Shapiro', 'http://localhost:8081/img/right side of history.jpg', 'n 2016, Ben Shapiro spoke at UC Berkeley. Hundreds of police officers were required from 10 UC campuses across the state to protect his speech, which was -- ironically -- about the necessity for free speech and rational debate.\r\n\r\nHe came to argue that Western Civilization is in the midst of a crisis of purpose and ideas. Our freedoms are built upon the twin notions that every human being is made in God’s image and that human beings were created with reason capable of exploring God’s world.\r\n\r\nWe can thank these values for the birth of science, the dream of progress, human rights, prosperity, peace, and artistic beauty. Jerusalem and Athens built America, ended slavery, defeated the Nazis and the Communists, lifted billions from poverty and gave billions spiritual purpose. Jerusalem and Athens were the foundations of the Magna Carta and the Treaty of Westphalia; they were the foundations of Declaration of Independence, Abraham Lincoln’s Emancipation Proclamation, and Martin Luther King Jr.’s Letter from Birmingham Jail.\r\n\r\nCivilizations that rejected Jerusalem and Athens have collapsed into dust. The USSR rejected Judeo-Christian values and Greek natural law, substituting a new utopian vision of “social justice” – and they starved and slaughtered tens of millions of human beings. The Nazis rejected Judeo-Christian values and Greek natural law, and they shoved children into gas chambers. Venezuela rejects Judeo-Christian values and Greek natural law, and citizens of their oil-rich nation have been reduced to eating dogs. \r\n\r\nWe are in the process of abandoning Judeo-Christian values and Greek natural law, favoring instead moral subjectivism and the rule of passion. And we are watching our civilization collapse into age-old tribalism, individualistic hedonism, and moral subjectivism. We believe we can reject Judeo-Christian values and Greek natural law and satisfy ourselves with intersectionality, or scientific materialism, or progressive politics, or authoritarian governance, or nationalistic solidarity.\r\n\r\nWe can’t.\r\n\r\nThe West is special, and in The Right Side of History, Ben Shapiro bravely explains that it’s because too many of us have lost sight of the moral purpose that drives us each to be better, or the sacred duty to work together for the greater good, or both. A stark warning, and a call to spiritual arms, this book may be the first step in getting our civilization back on track.', '0062857908', '978-0062857903', 'Broadside Books (March 19, 2019)');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pinjam`
--

CREATE TABLE `tb_pinjam` (
  `id_pinjam` int(10) NOT NULL,
  `booktitle` varchar(255) NOT NULL,
  `bookauthor` varchar(255) NOT NULL,
  `collect_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pinjam`
--

INSERT INTO `tb_pinjam` (`id_pinjam`, `booktitle`, `bookauthor`, `collect_date`) VALUES
(1, 'Becoming : Michelle Obama', 'Michelle Obama', '2019-05-06');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `useremail` varchar(100) NOT NULL,
  `userpassword` varchar(255) NOT NULL,
  `username` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_book`
--
ALTER TABLE `tb_book`
  ADD PRIMARY KEY (`id_book`);

--
-- Indexes for table `tb_pinjam`
--
ALTER TABLE `tb_pinjam`
  ADD PRIMARY KEY (`id_pinjam`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_book`
--
ALTER TABLE `tb_book`
  MODIFY `id_book` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_pinjam`
--
ALTER TABLE `tb_pinjam`
  MODIFY `id_pinjam` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
